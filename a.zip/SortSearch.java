public class SortSearch {
    public static int binarySearchIterative(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;
        int mid = 0;
        while (low < high) {
            mid = (low + high) / 2;
            if (key == arr[mid]) {
                return mid;
            } else if (key < arr[mid]) {
                high = mid - 1;
            } else if (key > arr[mid]) {
                low = mid + 1;
            }
        }
        return -1;
    }

    /* ----------- Recursive BinarySearch START ----------- */

    public static int binarySearchRecursive(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;
        return binarySearchRecursive(arr, key, low, high);
    }

    public static int binarySearchRecursive(int[] arr, int key, int low, int high) {
        if (low > high) {
            return -1;
        }
        int mid = (low + high) / 2;
        if (key == arr[mid]) {
            return mid;
        } else if (key < arr[mid]) {
            return binarySearchRecursive(arr, key, low, mid - 1);
        } else if (key > arr[mid]) {
            return binarySearchRecursive(arr, key, mid + 1, high);
        }
        return -1;
    }

    /* ----------- Recursive BinarySearch END ----------- */

    public static int[] insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i]; // 2
            int j = i - 1; // 0
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j]; // 2
                j = j - 1; // -1
            }
            arr[j + 1] = key; // 2
        }
        return arr;
    }

    public static int[] selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) { // 0
            int minIndex = i; // 0
            for (int j = i + 1; j < n; j++) { // 1
                if (arr[j] < arr[minIndex]) { // 2 < 1
                    minIndex = j; // 1
                }
            }
            int temp = arr[minIndex]; // 1
            arr[minIndex] = arr[i]; // 1
            arr[i] = temp; // 2
        }
        return arr;
    }

    public static int[] bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) { // 0
            for (int j = 0; j < n - i - 1; j++) { // 1
                if (arr[j] > arr[j + 1]) { // 2 > 1
                    int temp = arr[j]; // 2
                    arr[j] = arr[j + 1]; // 1
                    arr[j + 1] = temp; // 2
                }
            }
        }
        return arr;
    }

    /* ----------- MergeSort START ----------- */

    public static int[] mergeSort(int[] arr) {
        int n = arr.length;
        if (n < 2) {
            return arr;
        }
        int mid = n / 2;
        int[] left = new int[mid];
        int[] right = new int[n - mid];
        for (int i = 0; i < mid; i++) {
            left[i] = arr[i];
        }
        for (int j = mid; j < n; j++) {
            right[j - mid] = arr[j];
        }
        mergeSort(left);
        mergeSort(right);
        merge(left, right, arr);
        return arr;
    }

    public static void merge(int[] left, int[] right, int[] arr) {
        int nL = left.length;
        int nR = right.length;
        int i = 0;
        int j = 0;
        int k = 0;
        while (i < nL && j < nR) {
            if (left[i] <= right[j]) {
                arr[k] = left[i];
                i++;
            } else if (left[i] > right[j]) {
                arr[k] = right[j];
                j++;
            }
            k++;
        }
        while (i < nL) {
            arr[k] = left[i];
            i++;
            k++;
        }
        while (j < nR) {
            arr[k] = right[j];
            j++;
            k++;
        }
    }

    /* ----------- MergeSort END ----------- */

    /* ----------- QuickSort START ----------- */

    public static int[] quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1); // 0, 0
            quickSort(arr, pi + 1, high); // 2, 2
        }
        return arr;
    }

    public static int partition(int[] arr, int low, int high) {
        int pivot = arr[high]; // 2
        int i = low - 1; // -1
        for (int j = low; j < high; j++) { // 0
            if (arr[j] < pivot) { // 1 < 2
                i++; // 0
                int temp = arr[i]; // 1
                arr[i] = arr[j]; // 1
                arr[j] = temp; // 2
            }
        }
        int temp = arr[i + 1]; // 2
        arr[i + 1] = arr[high]; // 2
        arr[high] = temp; // 2
        return i + 1; // 2
    }
    
    /* ----------- QuickSort END ----------- */
}
