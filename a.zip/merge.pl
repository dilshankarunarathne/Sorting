
merge_sort([], []).
merge_sort([X], [X]).


merge_sort(List, Sorted) :-
    List = [_|_],  % Ensure the list has at least two elements
    split(List, Left, Right),
    merge_sort(Left, SortedLeft),
    merge_sort(Right, SortedRight),
    merge(SortedLeft, SortedRight, Sorted).


split(List, Left, Right) :-
    length(List, Len),
    HalfLen is Len // 2,
    length(Left, HalfLen),
    append(Left, Right, List).


merge([], Right, Right).
merge(Left, [], Left).
merge([X|Left], [Y|Right], [X|Sorted]) :-
    X =< Y,
    merge(Left, [Y|Right], Sorted).
merge([X|Left], [Y|Right], [Y|Sorted]) :-
    X > Y,
    merge([X|Left], Right, Sorted).
