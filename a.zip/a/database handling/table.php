<?php
    /*
     * create a table named "Students", with nine columns: 
     * "title", "firstname", "lastname", "reg_no”,”index_no”, “date_of_birth”, “email", “course” and "address". 
     * If the table is created successfully print a message as “Table Students created successfully”, 
     * otherwise print a message as “Error creating table”. 
     
     * title            VARCHAR         Maximum 05 characters 
     * firstname        VARCHAR         Maximum 40 characters 
     * lastname         VARCHAR         Maximum 40 characters 
     * reg_no           VARCHAR         Maximum 20 characters 
     * index_no integer PRIMARY KEY     AUTO_INCREMENT 
     * date_of_birth    TIMESTAMP       - 
     * email            VARCHAR         Maximum 50 characters 
     * course           VARCHAR         Maximum 20 characters 
     * address          VARCHAR         Maximum 60 characters -
    */

    // Create connection
    $conn = new mysqli("localhost", "root", "", "fasDB");

    // Check connection
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
    // echo "Connection successful<br>";

    // Create table
    $sql = "CREATE TABLE Students (
        title VARCHAR(5),
        firstname VARCHAR(40),
        lastname VARCHAR(40),
        reg_no VARCHAR(20),
        index_no integer PRIMARY KEY AUTO_INCREMENT,
        date_of_birth TIMESTAMP,
        email VARCHAR(50),
        course VARCHAR(20),
        address VARCHAR(60)
    )";
    

    if ($conn->query($sql) === TRUE)
    {
        echo "Table Students created successfully";
    }
    else
    {
        echo "Error creating table: " . $conn->error;
    }

    $conn->close();
?>
