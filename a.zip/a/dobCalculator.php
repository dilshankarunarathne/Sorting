<!DOCTYPE html>
<html>
<head>
    <title>Date of Birth Calculator</title>
</head>
<body>

<div style="border:3px solid black;">
<div style="border:1px solid black;">
<form method="post" action="dobCalculator.php">
		<h3><center>Date of Birth Calculator</center></h2>
		
		<label name="nic">Enter the NIC No.</label>
		<input type="text" id="nicNo" name="nic" required>
		<input type="submit" name="submit" value="Calculate"><br><br>
</form>
</div>


<?php

$result = array(
        'Gender' => '',
        'Year' => '',
        'Month' => '',
        'Day' => '',
        'DateOfBirth' => ''
    );

function calculateOldNICDOB($nic) {
    $year = substr($nic, 0, 2);
    $days = substr($nic, 2, 3);
    
    // Determine the gender based on the last character
    $gender = (strtoupper(substr($nic, -1)) === 'V') ? 'Female' : 'Male';
    
    // Calculate the birth year
    $birthYear = 1900 + intval($year);
    
    // Calculate the birth date
    $startOfYear = strtotime($birthYear . '-01-01');
    $birthDate = date('Y-m-d', strtotime('+' . ($days - 1) . ' days', $startOfYear));
    
	return array(
        'Gender' => $gender,
        'Year' => $birthYear,
        'Month' => date('F', strtotime($birthDate)),
        'Day' => date('d', strtotime($birthDate)),
        'DateOfBirth' => date('dS F Y', strtotime($birthDate))
    );
	
}

function calculateNewNICDOB($nic) {
    $year = substr($nic, 0, 4);
    $days = substr($nic, 4, 3);
    
    // Determine the gender based on the total number of days
    $gender = ($days > 500) ? 'Female' : 'Male';
    $days = ($days > 500) ? $days - 500 : $days;
    
    // Calculate the birth date
    $startOfYear = strtotime($year . '-01-01');
    $birthDate = date('Y-m-d', strtotime('+' . ($days - 1) . ' days', $startOfYear));
    
	
    return array(
        'Gender' => $gender,
        'Year' => $birthYear,
        'Month' => date('F', strtotime($birthDate)),
        'Day' => date('d', strtotime($birthDate)),
        'DateOfBirth' => date('dS F Y', strtotime($birthDate))
    );
	
}

// Main program
if (isset($_POST['nic'])) {
	$nic = $_POST['nic'];
    
    if (preg_match('/^\d{9}[Vv]$/', $nic)) {
        $result = calculateOldNICDOB($nic);
    } else if (preg_match('/^\d{12}$/', $nic)) {
        $result = calculateNewNICDOB($nic);
    } else {
        $error = 'Invalid NIC format';
    }
}
?>
 
<form action="gptCalculator.php">
<label>Gender:</label><label><?php echo $result['Gender']; ?></label><br>
<label>Year:</label><label><?php echo $result['Year']; ?></label><br>
<label>Month:</label><label><?php echo $result['Month']; ?></label><br>
<label>Day:</label><label><?php echo $result['Day']; ?></label><br>
<label>Date of Birth:</label><label><?php echo $result['DateOfBirth']; ?></label><br>
</form>   
</div>
    
</body>
</html>