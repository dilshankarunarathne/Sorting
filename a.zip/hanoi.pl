
%*********************tower of hanoi***************************
move(1,X,Y,_):- write('move top disk from '),write(X),write(' to '), write(Y),nl.

move(N,X,Y,Z):- N > 1,M is N - 1,move(M,X,Z,Y),move(1,X,Y,_),move(M,Z,Y,X).

%*********************duplicate check****************************************
asc_sort([],[]).
asc_sort(List,[Min|SortedRest]):-
                                  min_list(List,Min),
								  select(Min,List,Rest),
								  asc_sort(Rest,SortedRest).
								  compress([],[]).
compress([X],[X]).
compress([X,X|T],T1):-compress([X|T],T1).
compress([X,Y|T],[X|T1]):-compress([Y|T],T1),X\=Y.
								  
duplicate(L,L1):-asc_sort(L,L2),compress(L2,L1),!.

