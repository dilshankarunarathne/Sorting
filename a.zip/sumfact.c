#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

/*

Takes an integer argument (say, N1) from the command line.
Forks two children processes
    First child computes 1+2+...+N1 (sum of positive integers up to N1) and prints out the result and its own identifier.
    Second child computes 1*2*...*N1 (the factorial of N1) and prints out the result and its own identifier.
Parent waits until both children are finished, then prints out the message “Done” and its own identifier.

Sample execution,
Input value is: 5
Output as:
    Sum of positive integers up to 5 is 15
    Factorial of 5 is 120
    Done

*/

int factorial(int n) {
    int fact = 1;
    for (int i = 1; i <= n; i++) {
        fact *= i;
    }
    return fact;
}

int sum(int n) {
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <integer>\n", argv[0]);
        return 1;
    }

    int N1 = atoi(argv[1]);

    if (N1 <= 0) {
        printf("Input value must be a positive integer\n");
        return 1;
    }

    pid_t child1, child2;
    int status1, status2;

    child1 = fork();

    if (child1 == 0) {
        // First child process computes the sum
        int sum_result = sum(N1);
        printf("Sum of positive integers up to %d is %d\n", N1, sum_result);
        printf("First child process ID: %d\n", getpid());
        exit(0);
    } else if (child1 > 0) {
        child2 = fork();

        if (child2 == 0) {
            // Second child process computes the factorial
            int fact_result = factorial(N1);
            printf("Factorial of %d is %d\n", N1, fact_result);
            printf("Second child process ID: %d\n", getpid());
            exit(0);
        } else if (child2 > 0) {
            // Parent process waits for both children to finish
            waitpid(child1, &status1, 0);
            waitpid(child2, &status2, 0);
            printf("Done\n");
            printf("Parent process ID: %d\n", getpid());
        } else {
            printf("Error occurred while forking the second child\n");
            return 1;
        }
    } else {
        printf("Error occurred while forking the first child\n");
        return 1;
    }

    return 0;
}
