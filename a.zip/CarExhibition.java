abstract class Car {
	double price;
	int year;

	public Car(double price, int year) {
		this.price = price;
		this.year = year;
	}

	public abstract double calculateSalePrice(); 

	@Override 
	public String toString() {
		return "Car {price: " + price + ", year: " + year + "}";
	}
}

class ClassicCar extends Car {
	public ClassicCar(double price, int year) {
		super(price, year);
	}

	@Override
	public double calculateSalePrice() {
		return 10000;
	}
}

class SportsCar extends Car {
	public SportsCar(double price, int year) {
		super(price, year);
	}

	@Override
	public double calculateSalePrice() {
		if (year > 2015) {
			return price * 1.75;
		} else if (year > 2005) {
			return price * 1.5;
		} else {
			return price * 1.25;
		}
	}
}

public class CarExhibition {
	private Car [] _array;
	private int _size = 20;
	private int _i = 0;

	public CarExhibition() {
		_array = new Car [_size];
	}

	void addClassicCar(double price, int year) {
		_array[_i++] = new ClassicCar(price, year);
	}

	void addSportsCar(double price, int year) {
		_array[_i++] = new SportsCar(price, year);
	}

	double getTotalPrice() {
		double totalPrice = 0;
		for (int i=0; i<_i; i++) {
			totalPrice += _array[i].calculateSalePrice();
		}
		return totalPrice;
	}
}
