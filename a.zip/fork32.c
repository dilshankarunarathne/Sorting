#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// c program that prints "hello" 32 times by using fork() and for loop.

int main() {
    int i;
    for (i = 0; i < 32; i++) {
        pid_t child_pid = fork();

        if (child_pid == 0) {
            // Child process
            printf("hello\n");
            exit(0);
        } else if (child_pid > 0) {
            // Parent process
            wait(NULL); // Wait for the child process to finish
        } else {
            printf("Error occurred while forking\n");
            exit(1);
        }
    }

    return 0;
}
