%*******************print_list***********************************
print_list([]).
print_list([H|T]):-write(H),write(' '),print_list(T).

%********************check member**********************************
membership(X,[X|T]).
membership(X,[Y|T]):-membership(X,T).

%********************concat list**********************************
concat_list([],L,L).
concat_list([X|L1],L2,[X|L3]):-concat_list(L1,L2,L3).

%**********************delete_element********************************
delete_item(X,[X|T],T).
delete_item(X,[Y|T],[Y|T1]):-delete_item(X,T,T1).

%************************permutation_list******************************
insert(X,L,[X|L]).
insert(X,[H|T],[H|T1]):-insert(X,T,T1).
permutation1([],[]).
permutation1([X|L],P):-permutation1(L,L1),insert(X,L1,P).

%*******************check even or odd***********************************
evenlength([]).
evenlength([_|T]):-oddlength(T).
oddlength([_]).
oddlength([_|T]):-evenlength(T).

%**********************reverse_list********************************
addtoend(H,[],[H]).
addtoend(X,[H|T],[H|T1]):-addtoend(X,T,T1).
reversex([],[]).
reversex([X|T],Y):-reversex(T,T1),addtoend(X,T1,Y).

%***********************palindrome list*******************************
palindrome(List):-reversex(List,R),List=R.

%**********************shift list********************************
shiftList([H|T],L):-append(T,[H],L).

%********************find gcd**********************************
gcd(X,X,X).
gcd(X,Y,D):- X<Y, Y1 is Y - X,gcd(X,Y1,D).
gcd(X,Y,D):- X>Y, X1 is X - Y,gcd(X1,Y,D).

%********************number ekta adalawa ehi english word eka check karai**********************************
means(1,one).
means(2,two).
translate([],[]).
translate([Num|T1],[Word|T2]):-means(Num,Word),translate(T1,T2).

%********************length of list**********************************
count_list([],0).
count_list([_|T],N):- count_list(T,N1),N is N1 + 1.

%********************ascending sort**********************************
asc_sort([],[]).
asc_sort(List,[Min|SortedRest]):-
                                  min_list(List,Min),
								  select(Min,List,Rest),
								  asc_sort(Rest,SortedRest).

%********************descending sort**********************************								  
dsc_sort([],[]).
dsc_sort(List,[Max|SortedRest]):-
                                  max_list(List,Max),
								  select(Max,List,Rest),
								  dsc_sort(Rest,SortedRest).

%*****************find max from list*************************************								  
maxList([X],X).
maxList([X|Xs],M):-maxList(Xs,M),M>=X.
maxList([X|Xs],X):-maxList(Xs,M),X>M.

%*******************get index to given element***********************************
index_mem(X,[],0).
index_mem(X,[X|R],1).
index_mem(X,[Y|R],I):-index_mem(X,R,I1),I is I1 + 1,I1\=0.

%************************delete given index element******************************
del_index(1,[_|T],T).
del_index(I,[Y|T],[Y|T1]):-
                           I > 1,
						   I1 is I - 1,
                           del_index(I1,T,T1).

%******************sumation of the list************************************						   
sum_list([],0).
sum_list([H|T],Sum):- sum_list(T,Sum2),Sum is H + Sum2.

%*******************multiplication of the list element***********************************
mul_list([],1).
mul_list([H|T],S):- mul_list(T,S2),S is H * S2.

%*********************divide given list into equal parts*********************************
divide_list(List,L1,L2):-
                         length(List,Len),
						 Hlen is Len // 2,
						 length(L1,Hlen),
						 append(L1,L2,List).

%**********************get last element of the list********************************						 
last_el([X],X).
last_el([_|T],X):-last_el(T,X).

%*******************check vowel***********************************
vowel(a).
vowel(e).

count_vowel([X|R],N):-vowel(X),
					  count_vowel(R,M),
					  N is M + 1.
count_vowel([_|R],N):-count_vowel(R,N).

%**********************difference of set********************************
difference([L],[],[L]).
difference(List,[X|R],Diff):-
                             select(X,List,List2),
							 difference(List2,R,Diff).

%*******************create list using given two numbers***********************************							 
between(X,X,[X]).
between(X,Y,[X|L]):-Y>=X,
                    between(M,Y,L),
					M is X + 1.

%*********************get the sub list for given input number from the big list*********************************					
sub_sum([],0,[]).
sub_sum([X|T],Sum,List):-Sum>=X,
						 Sum2 is Sum - X,
                         sub_sum(T,Sum2,List).
sub_sum([_|T],Sum,List):-sub_sum(T,Sum,List).

%****************eka laga eka wage pawathin duplicate iwath karai**************************************
compress([],[]).
compress([X],[X]).
compress([X,X|T],T1):-compress([X|T],T1).
compress([X,Y|T],[X|T1]):-compress([Y|T],T1),X\=Y.

%*****************list eka order ekata thiyenwda balai*************************************
ordered([X]).
ordered([X,Y|R]):-Y>=X,ordered([Y|R]).

%*********************find mean using sum and length of list*********************************
mean(L,X):-sum_list(L,Sum),count_list(L,C),X is Sum/C.

%******************check the number is in the given list************************************
numberinlist([]):-fail.
numberinlist([X|T]):-number(X).
numberinlist([X|T]):-numberinlist(T).

%***********************increment the element value by one*******************************
increment([],[]).
increment([H|T],[H2|Y]):-H2 is H + 1,increment(T,Y).

%*********************factorial*********************************
factorial(0,1).
factorial(N,F):-N>0, N1 is N - 1, factorial(N1,F1), F is N * F1.

%*********************list eke pawathin elemnet eken ekata  [] danawa*********************************
encapsulate([],[]).
encapsulate([X|T],[[X]|T1]):-encapsulate(T,T1).

%********************element ekak pitupasata 0 add kirima**********************************
inser_zero([],[]).
inser_zero([H|T],[H,0|Y]):-inser_zero(T,Y).

%*********************list ekaka copy dekak ganima*********************************
clone_list(T,[T,T]).

/*mehidi dena index ekaka value eke wenas karai*/

modify_list([],N,X,[]).
modify_list([H|T],0,X,[X|T]).          
modify_list([H|T],N,X,[H|T1]):-N>0,N1 is N - 1,modify_list(T,N1,X,T1).

%*********************fibonanci*********************************
fib(1,1).
fib(2,1).
fib(N,F):-N>2,
          N1 is N - 1, 
		  fib(N1,F1),
		  N2 is N - 2,
		  fib(N2,F2),
		  F is F1 + F2.
		  
%********************rotate list**********************************
rotate([],_,[]).
rotate(List, 0, List).
rotate([H|T], N, RotatedList) :-
    N > 0,
	N1 is N - 1,
    rotate(T, N1, RotatedTail),
    append(RotatedTail, [H], RotatedList).
rotate(List, N, RotatedList) :-
    N < 0,
    length(List, Length),
    N1 is Length + N,
    rotate(List, N1, RotatedList).

%***************list kisima thanaka eka wage element nomatha eya sort saha compress kara iwat karai*****************************************
duplicate(L,L1):-asc_sort(L,L2),compress(L2,L1),!.

%********************************************************