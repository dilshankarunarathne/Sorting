import java.util.Scanner;

public class FCFS {
    private static final Scanner scanner = new Scanner(System.in);
    private static String[] _PID;
    private static int[] _BT, _CT, _TAT, _WT;

    public static void main(String[] args) {
        System.out.println("First Come First Serve (FCFS) Scheduling Algorithm");

        System.out.print("Enter the number of processes: ");
        int _N = scanner.nextInt();
        scanner.nextLine();

        // Initialize the arrays
        _BT = new int[_N];
        _CT = new int[_N];
        _TAT = new int[_N];
        _WT = new int[_N];
        _PID = new String[_N];

        // Get the burst time of each process
        int wait = 0;
        for (int i = 0; i < _N; i++) {
            System.out.print("Enter the process ID of process " + (i + 1) + ": ");
            _PID[i] = scanner.nextLine();

            System.out.print("Enter the burst time of process " + _PID[i] + ": ");
            _BT[i] = scanner.nextInt();
            scanner.nextLine();

            // Calculate the completion time, turnaround time and waiting time
            _WT[i] = wait;
            wait += _BT[i];

            _TAT[i] = _CT[i] = _BT[i] + _WT[i];
        }

        System.out.println("PID\t\tBT\t\tCT\t\tTAT\t\tWT");
        for (int i = 0; i < _N; i++) {
            System.out.println(_PID[i] + "\t\t" + _BT[i] + "\t\t" + _CT[i] + "\t\t" + _TAT[i] + "\t\t" + _WT[i]);
        }

        // Calculate the average turnaround time and waiting time
        float avgTAT = 0, avgWT = 0;
        for (int i = 0; i < _N; i++) {
            avgTAT += _TAT[i];
            avgWT += _WT[i];
        }
        avgTAT /= _N;
        avgWT /= _N;

        System.out.println("Average TAT: " + avgTAT);
        System.out.println("Average WT: " + avgWT);

        scanner.close();
    }
}
