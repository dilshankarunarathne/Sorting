day(sunday).
day(monday).
day(tuesday).
day(wednesday).
day(thursday).
day(friday).
no_office(saturday).
no_office(sunday).
take_leave(monday).

visit_mom(X) :- no_office(X), take_leave(X).
working_day(X) :- day(X),\+no_office(X),\+take_leave(X).
