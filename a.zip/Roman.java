import java.util.Scanner;

public class Roman {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the operation: (roman->decimal: 1, decimal->roman: 2) > ");
        int operation = scanner.nextInt();
        scanner.nextLine();
        
        if (operation == 1) {
            System.out.println("Enter the roman number: ");
            String roman = scanner.nextLine();
            System.out.println("Decimal: " + romanToDecimal(roman));
        } else if (operation == 2) {
            System.out.println("Enter the decimal number: ");
            int decimal = scanner.nextInt();
            System.out.println("Roman: " + decimalToRoman(decimal));
        } else {
            System.out.println("Invalid operation.");
        }
    }

    private static String decimalToRoman(int decimal) {
        String roman = "";

        while (decimal > 0) {
            if (decimal >= 1000) {
                roman += "M";
                decimal -= 1000;
            } else if (decimal >= 900) {
                roman += "CM";
                decimal -= 900;
            } else if (decimal >= 500) {
                roman += "D";
                decimal -= 500;
            } else if (decimal >= 400) {
                roman += "CD";
                decimal -= 400;
            } else if (decimal >= 100) {
                roman += "C";
                decimal -= 100;
            } else if (decimal >= 90) {
                roman += "XC";
                decimal -= 90;
            } else if (decimal >= 50) {
                roman += "L";
                decimal -= 50;
            } else if (decimal >= 40) {
                roman += "XL";
                decimal -= 40;
            } else if (decimal >= 10) {
                roman += "X";
                decimal -= 10;
            } else if (decimal >= 9) {
                roman += "IX";
                decimal -= 9;
            } else if (decimal >= 5) {
                roman += "V";
                decimal -= 5;
            } else if (decimal >= 4) {
                roman += "IV";
                decimal -= 4;
            } else if (decimal >= 1) {
                roman += "I";
                decimal -= 1;
            }
        }

        return roman;
    }

    private static String romanToDecimal(String roman) {
        roman = roman.toUpperCase();

        int total = 0;
        int previous = 0;

        for (int i=roman.length()-1; i>=0; i--) {
            char c = roman.charAt(i);
            int value = getDecimalValue(c);

            if (value < previous) {
                total -= value;
            } else {
                total += value;
            }

            previous = value;
        }

        return String.valueOf(total);
    }

    private static int getDecimalValue(char c) {
        switch (c) {
            case 'I':
                return 1;
            case 'V':
                return 5;
            case 'X':
                return 10;
            case 'L':
                return 50;
            case 'C':
                return 100;
            case 'D':
                return 500;
            case 'M':
                return 1000;
            default:
                throw new RuntimeException("No matching character: " + c);
        }
    }
}
