<?php
// Function to convert decimal number to Roman numerals
function decimalToRoman($number) {
    $romanNumerals = array(
        'M' => 1000,
        'CM' => 900,
        'D' => 500,
        'CD' => 400,
        'C' => 100,
        'XC' => 90,
        'L' => 50,
        'XL' => 40,
        'X' => 10,
        'IX' => 9,
        'V' => 5,
        'IV' => 4,
        'I' => 1
    );

    $result = '';

    foreach ($romanNumerals as $roman => $decimal) {
        while ($number >= $decimal) {
            $result .= $roman;
            $number -= $decimal;
        }
    }

    return $result;
}

// Function to convert Roman numerals to decimal number
function romanToDecimal($romanNumeral) {
    $romanNumerals = array(
        'M' => 1000,
        'CM' => 900,
        'D' => 500,
        'CD' => 400,
        'C' => 100,
        'XC' => 90,
        'L' => 50,
        'XL' => 40,
        'X' => 10,
        'IX' => 9,
        'V' => 5,
        'IV' => 4,
        'I' => 1
    );

    $result = 0;

    foreach ($romanNumerals as $roman => $decimal) {
        while (strpos($romanNumeral, $roman) === 0) {
            $result += $decimal;
            $romanNumeral = substr($romanNumeral, strlen($roman));
        }
    }

    return $result;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conversionType = $_POST['conversion_type'];
    $inputValue = $_POST['input_value'];

    $result = '';

    if ($conversionType === 'decimal_to_roman') {
        $result = decimalToRoman($inputValue);
    } elseif ($conversionType === 'roman_to_decimal') {
        $result = romanToDecimal($inputValue);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Decimal and Roman Numeral Converter</title>
</head>
<body>
    <h1>Decimal and Roman Numeral Converter</h1>

    <form method="POST" action="">
        <label for="conversion_type">Conversion Type:</label>
        <select id="conversion_type" name="conversion_type">
            <option value="decimal_to_roman">Decimal to Roman</option>
            <option value="roman_to_decimal">Roman to Decimal</option>
        </select>
        <br><br>
        <label for="input_value">Input Value:</label>
        <input type="text" id="input_value" name="input_value">
        <br><br>
        <input type="submit" value="Convert">
    </form>

    <?php if (isset($result)) : ?>
        <h2>Result: <?php echo $result; ?></h2>
    <?php endif; ?>
</body>
</html>