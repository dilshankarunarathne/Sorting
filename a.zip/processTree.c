#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

// Write a program tree.c that creates the tree of processes. 
// Each process in the tree should print its own identifier.

int main() {
    pid_t root_pid = getpid();
    printf("I am the root parent\n");
    printf("My parent is [%d]\n", getppid());

    pid_t child1_pid = fork();
    if (child1_pid == 0) {
        // First child (C1) process
        printf("My parent is [%d]\n", getppid());
        pid_t child3_pid = fork();
        if (child3_pid == 0) {
            // First child's child (C3) process
            printf("My parent is [%d]\n", getppid());
            exit(0);
        } else if (child3_pid > 0) {
            wait(NULL); // Wait for the child (C3) process to finish
            exit(0);
        } else {
            printf("Error occurred while forking child3\n");
            exit(1);
        }
    } else if (child1_pid > 0) {
        pid_t child2_pid = fork();
        if (child2_pid == 0) {
            // Second child (C2) process
            printf("My parent is [%d]\n", getppid());
            pid_t child4_pid = fork();
            if (child4_pid == 0) {
                // Second child's child (C4) process
                printf("My parent is [%d]\n", getppid());
                exit(0);
            } else if (child4_pid > 0) {
                wait(NULL); // Wait for the child (C4) process to finish
                exit(0);
            } else {
                printf("Error occurred while forking child4\n");
                exit(1);
            }
        } else if (child2_pid > 0) {
            // Parent process (P)
            wait(NULL); // Wait for both children (C1 and C2) to finish
        } else {
            printf("Error occurred while forking child2\n");
            exit(1);
        }
    } else {
        printf("Error occurred while forking child1\n");
        exit(1);
    }

    if (getpid() == root_pid) {
        printf("Parent process ID: %d\n", getpid());
    }

    return 0;
}
