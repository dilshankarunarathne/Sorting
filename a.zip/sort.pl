asc_sort([],[]).
asc_sort(List,[Min|SortedRest]):-
                                  min_list(List,Min),
								  select(Min,List,Rest),
								  asc_sort(Rest,SortedRest).
								  compress([],[]).
compress([X],[X]).
compress([X,X|T],T1):-compress([X|T],T1).
compress([X,Y|T],[X|T1]):-compress([Y|T],T1),X\=Y.
								  
duplicate(L,L1):-asc_sort(L,L2),compress(L2,L1),!.