class Publication {
    private String title;
    private double price;
    
    public Publication(String title, double price) {
        this.title = title;
        this.price = price;
    }
    
    public String getTitle() {
        return title;
    }
    
    public double getPrice() {
        return price;
    }
    
    public void print() {
        System.out.println("Title: " + title);
        System.out.println("Price: $" + price);
    }
}

// Book interface
interface Book {
    String getAccessionNumber();
    void print();
}

// Magazine interface
interface Magazine {
    int getVolumeNumber();
    void print();
}

// Journal class implementing Book and Magazine interfaces
class Journal implements Book, Magazine {
    private String accessionNumber;
    private int volumeNumber;
    
    public Journal(String accessionNumber, int volumeNumber) {
        this.accessionNumber = accessionNumber;
        this.volumeNumber = volumeNumber;
    }
    
    @Override
    public String getAccessionNumber() {
        return accessionNumber;
    }
    
    @Override
    public int getVolumeNumber() {
        return volumeNumber;
    }
    
    @Override
    public void print() {
        System.out.println("Accession Number: " + getAccessionNumber());
        System.out.println("Volume Number: " + getVolumeNumber());
    }
}

public class BookPublication {
    public static void main(String[] args) {
        Journal journal = new Journal("A123", 5);
        journal.print();
        
        System.out.println("---");
        
        Publication publication = new Publication("Sample Publication", 10.99);
        publication.print();
    }
}