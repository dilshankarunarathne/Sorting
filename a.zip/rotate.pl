rotate_list([], _, []).
rotate_list(List, 0, List).
rotate_list([X|Rest], N, Rotated) :-
    N > 0,
    append(Rest, [X], NewList),
    N1 is N - 1,
    rotate_list(NewList, N1, Rotated).
rotate_list(List, N, Rotated) :-
    N < 0,
    length(List, Len),
    N1 is N mod Len,
    rotate_list(List, N1, Rotated).
