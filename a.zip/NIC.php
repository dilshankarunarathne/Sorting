<!DOCTYPE html>

<html>
<head>
	<title>DOB Calculator</title>
	<style type="text/css">
		.right-aligned {
			text-align: right;
		}
		.left-aligned {
			text-align: left;
		}
		.form {
			margin: auto;
			width: 35%;
			border: 3px solid black;
			padding: 10px;
		}
		.error {
			color: red;
			font-weight: bold;
		}
	</style>
</head>
<body>

<?php

$gender = $year = $month = $date = $dob = $err = $mid = $days = "";
$err_f = false;

if (isset($_POST['nic'])) {
	$nic = $_POST['nic'];

	if (!is_valid($nic)) {
		$err = "This does not seem like a valid NIC number!"; 
		$err_f = true;
	}

	// year calculation 
	if (strlen($nic) == 10) {
		$year = '19' . substr($nic, 0, 2);
		$mid = intval(substr($nic, 2, 3));
	} else {
		$year = substr($nic, 0, 4);
		$mid = intval(substr($nic, 4, 3));
	}

	// gender calculation
	if ($mid > 500) {
		$gender = 'Female';
		$days = $mid - 500;
	} else {
		$gender = 'Male';
		$days = $mid;
	}

	for ($i=1; $i<=12; $i++) {
		$n_days_of_cur_month = cal_days_in_month(CAL_GREGORIAN, $i, $year);

		if ($days <= $n_days_of_cur_month) {	// base case 
			$month = $i;
			$date = $days;
			break;
		} else {
			$days -= $n_days_of_cur_month;
		}
	}

	$date--;

	$dob = $date . '<sup>' . date_pf($date) . '</sup> ' . date("F", mktime(0, 0, 0, $month, 10)) . ' ' . $year;
}

function date_pf($date) : string {
	if ($date === 1) return 'st';
	if ($date === 2) return 'nd';
	if ($date === 3) return 'rd';
	return 'th';
}

function is_valid($nic) : bool {
	if (strlen($nic) != 10 && strlen($nic) != 12) {
		return false;
	}

	if (!is_numeric($nic)) { // not completely a numeric value 
		if (substr($nic, -1) == 'V' || substr($nic, -1) == 'v') { // ends with a V
			if (strlen($nic) == 10 && is_numeric(substr($nic, 0, 9))) {	// first 9 characters are numeric 
				return true;
			}
		}
		return false;
	}

	return true;
}

?>

<div class="form">
	<form action="dob.php" method="POST">
		<h2>Date of Birth Calculator</h1>

		<div class="inputs">
			<label>Enter the NIC no: </label>
			<input type="text" name="nic"></input>
			<input type="submit" value="Calculate"></input>
		</div>

		<div class="results" <?php if (isset($_POST['nic']) === false || $err_f === true){?>style="display:none"<?php } ?>>
			<table>
				<tr>
					<td class="right-aligned"><label>Gender:</label></td>
					<td class="left-aligned"><label><?php echo"$gender" ?></label></td>
				</tr>
				<tr>
					<td class="right-aligned"><label>Year:</label></td>
					<td class="left-aligned"><label><?php echo"$year" ?></label></td>
				</tr>
				<tr>
					<td class="right-aligned"><label>Month:</label></td>
					<td class="left-aligned"><label><?php echo"$month" ?></label></td>
				</tr>
				<tr>
					<td class="right-aligned"><label>Day:</label></td>
					<td class="left-aligned"><label><?php echo"$date" ?></label></td>
				</tr>
				<tr>
					<td class="right-aligned"><label>Date of Birth:</label></td>
					<td class="left-aligned"><label><?php echo"$dob" ?></label></td>
				</tr>
			</table>
		</div>

		<div class="error" <?php if ($err_f === false){?>style="display:none"<?php } ?>>
			<?php echo "Error: $err"; ?>
		</div>
		
	</form>
</div>
</body>
</html>
