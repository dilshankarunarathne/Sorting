male(dicky).
male(oliver).
male(jack).
male(george).
female(anne).
female(rose).
female(sophie).
parent(dicky,oliver).
parent(dicky,sophie).
parent(oliver,anne).
parent(oliver,mike).
parent(oliver,jack).
parent(sophie,rose).
parent(rose,george).
ancestor(dicky,george).

father(X,Y):-parent(X,Y),male(X).
mother(X,Y):-parent(X,Y),female(X).
sibling(X,Y):-parent(Z,X),parent(Z,Y),X\=Y.
sister(X,Y):-sibling(X,Y),female(X),X\=Y.
brother(X,Y):-sibling(X,Y),male(X),X\=Y.
grandmother(X,Y):- parent(Z,Y),parent(X,Z),female(X).
grandfather(X,Y):- parent(Z,Y),parent(X,Z),male(X).
cousin(X,Y):-parent(Z,X),parent(W,Y),sibling(Z,W),Z\=W.
uncle(X,Y):-parent(Z,Y),sibling(X,Z),male(X).
son(X,Y):-parent(Y,X),male(X).
daughter(X,Y):-parent(Y,X),female(X).


