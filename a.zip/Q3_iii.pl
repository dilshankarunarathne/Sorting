remove_parentheses([], []).
remove_parentheses([X|Rest], [X|Result]) :-
    \+ is_list(X),
    remove_parentheses(Rest, Result).
remove_parentheses([X|Rest], Result) :-
    is_list(X),
    remove_parentheses(X, InnerResult),
    remove_parentheses(Rest, RestResult),
    append(InnerResult, RestResult, Result).
