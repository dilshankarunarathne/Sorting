#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

/*

c program to store integers in an array.
then create 3 child processes from same parent process which perform various tasks using fork().
consider the return values from the fork() system calls to distinguish the parent/child processes to perform the following task.
1. parent process display all elements and number of elements of the array.
2. 1 st child process display all even elements and the sum of the even elements in the array.
3. 2 nd child process display all odd elements and sum of the odd elements of the array.
4. 3 rd child sort the array elements using bubble sort.

*/

void displayArray(int array[], int size) {
    printf("Array elements: ");
    for (int i = 0; i < size; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

int sumEvenElements(int array[], int size) {
    int sum = 0;
    printf("Even elements: ");
    for (int i = 0; i < size; i++) {
        if (array[i] % 2 == 0) {
            printf("%d ", array[i]);
            sum += array[i];
        }
    }
    printf("\n");
    return sum;
}

int sumOddElements(int array[], int size) {
    int sum = 0;
    printf("Odd elements: ");
    for (int i = 0; i < size; i++) {
        if (array[i] % 2 != 0) {
            printf("%d ", array[i]);
            sum += array[i];
        }
    }
    printf("\n");
    return sum;
}

void bubbleSort(int array[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (array[j] > array[j + 1]) {
                // Swap elements
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
}

int main() {
    int array[] = {5, 2, 9, 12, 4, 7, 6, 3, 1, 8};
    int size = sizeof(array) / sizeof(array[0]);

    pid_t child1, child2, child3;
    int status1, status2, status3;

    child1 = fork();

    if (child1 == 0) {
        // First child process
        displayArray(array, size);
        int sumEven = sumEvenElements(array, size);
        printf("Sum of even elements: %d\n", sumEven);
        exit(0);
    } else if (child1 > 0) {
        child2 = fork();

        if (child2 == 0) {
            // Second child process
            displayArray(array, size);
            int sumOdd = sumOddElements(array, size);
            printf("Sum of odd elements: %d\n", sumOdd);
            exit(0);
        } else if (child2 > 0) {
            child3 = fork();

            if (child3 == 0) {
                // Third child process
                bubbleSort(array, size);
                printf("Sorted array: ");
                displayArray(array, size);
                exit(0);
            } else if (child3 > 0) {
                // Parent process
                waitpid(child1, &status1, 0);
                waitpid(child2, &status2, 0);
                waitpid(child3, &status3, 0);
                printf("Parent process\n");
                printf("Number of elements: %d\n", size);
            } else {
                printf("Error occurred while forking the third child\n");
                return 1;
            }
        } else {
            printf("Error occurred while forking the second child\n");
            return 1;
        }
    } else {
        printf("Error occurred while forking the first child\n");
        return 1;
    }

    return 0;
}
