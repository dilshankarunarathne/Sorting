import java.util.Scanner;

public class RoundRobin {
    private static final Scanner scanner = new Scanner(System.in);

    private static String[] _PID;
    private static int[] _BT, _CT, _TAT, _WT;

    public static void main(String[] args) {
        System.out.print("Enter the number of processes: ");
        int _N = scanner.nextInt();
        scanner.nextLine();

        // Initializing the arrays
        _BT = new int[_N];
        _CT = new int[_N];
        _TAT = new int[_N];
        _WT = new int[_N];
        _PID = new String[_N];

        for (int i = 0; i < _N; i++) {
            System.out.print("Enter the process ID of process " + (i + 1) + ": ");
            _PID[i] = scanner.nextLine();

            System.out.print("Enter the burst time of process " + _PID[i] + ": ");
            _BT[i] = scanner.nextInt();
            scanner.nextLine();
        }

        System.out.print("Enter the time quantum: ");
        int _TQ = scanner.nextInt();
        scanner.nextLine();

        // Copying the burst time array
        int[] _BT2 = new int[_N];
        for (int i = 0; i < _N; i++) {
            _BT2[i] = _BT[i];
        }

        // Calculating the completion time
        int _time = 0;
        while (true) {
            boolean _done = true;
            // Looping through the burst time array
            for (int i = 0; i < _N; i++) {
                // If the burst time is greater than 0, then the process is not done
                if (_BT2[i] > 0) {
                    _done = false;
                    // If the burst time is greater than the time quantum, then the process is
                    if (_BT2[i] > _TQ) {
                        _time += _TQ;
                        _BT2[i] -= _TQ;
                    } else {    // If the burst time is less than or equal to the time quantum, then the process is done
                        _time += _BT2[i];
                        _BT2[i] = 0;
                        _CT[i] = _time;
                    }
                }
            }
            // If all the processes are done, then break out of the loop
            if (_done) {
                break;
            }
        }

        // Calculating the turnaround time and waiting time
        for (int i = 0; i < _N; i++) {
            _TAT[i] = _CT[i];
            _WT[i] = _TAT[i] - _BT[i];
        }

        System.out.println("PID\t\tBT\t\tCT\t\tTAT\t\tWT");
        for (int i = 0; i < _N; i++) {
            System.out.println(_PID[i] + "\t\t" + _BT[i] + "\t\t" + _CT[i] + "\t\t" + _TAT[i] + "\t\t" + _WT[i]);
        }

        // Calculating the average turnaround time and average waiting time
        float _avgTAT = 0, _avgWT = 0;
        for (int i = 0; i < _N; i++) {
            _avgTAT += _TAT[i];
            _avgWT += _WT[i];
        }
        _avgTAT /= _N;
        _avgWT /= _N;

        System.out.println("Average TAT: " + _avgTAT);
        System.out.println("Average WT: " + _avgWT);

        scanner.close();
    }
}
