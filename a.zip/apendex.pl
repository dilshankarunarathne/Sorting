appendx([],A,A).
appendx([H|T],A,[H|U]):-appendx(T,A,U).