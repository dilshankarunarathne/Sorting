import java.util.Scanner;

public class NPSJF {
    private static final Scanner scanner = new Scanner(System.in);

    private static String[] _PID;
    private static int[] _BT, _CT, _TAT, _WT;

    public static void main(String[] args) {
        System.out.println("Non-Preemptive Shortest Job First (SJF) Scheduling Algorithm");

        System.out.print("Enter the number of processes: ");
        int _N = scanner.nextInt();
        scanner.nextLine();

        // Initialize the arrays
        _BT = new int[_N];
        _CT = new int[_N];
        _TAT = new int[_N];
        _WT = new int[_N];
        _PID = new String[_N];

        for (int i = 0; i < _N; i++) {
            System.out.print("Enter the process ID of process " + (i + 1) + ": ");
            _PID[i] = scanner.nextLine();

            System.out.print("Enter the burst time of process " + _PID[i] + ": ");
            _BT[i] = scanner.nextInt();
            scanner.nextLine();
        }

        // Create a copy of _BT
        int[] _BT2 = new int[_N];
        for (int i = 0; i < _N; i++) {
            _BT2[i] = _BT[i];
        }

        // Sort _BT2 in ascending order
        int[] _P = new int[_N];
        for (int i = 0; i < _N; i++) {
            _P[i] = i;
        }

        // Sort _BT2 and _P in ascending order
        for (int i = 0; i < _N; i++) {
            // Sort _BT2
            for (int j = i + 1; j < _N; j++) {
                if (_BT[i] > _BT[j]) {
                    int temp = _BT[i];
                    _BT[i] = _BT[j];
                    _BT[j] = temp;

                    temp = _P[i];
                    _P[i] = _P[j];
                    _P[j] = temp;
                }
            }
        }

        // Calculate the completion time, turnaround time, and waiting time
        int wait = 0;
        for (int i = 0; i < _N; i++) {
            _WT[i] = wait;
            wait += _BT[i];

            _TAT[i] = _CT[i] = _BT[i] + _WT[i];
        }

        System.out.println("PID\t\tBT\t\tCT\t\tTAT\t\tWT");
        for (int i = 0; i < _N; i++) {
            System.out.println(_PID[_P[i]] + "\t\t" + _BT2[_P[i]] + "\t\t" + _CT[_P[i]] + "\t\t" + _TAT[_P[i]] + "\t\t" + _WT[_P[i]]);
        }

        // Calculate the average turnaround time and average waiting time
        float avgTAT = 0, avgWT = 0;
        for (int i = 0; i < _N; i++) {
            avgTAT += _TAT[i];
            avgWT += _WT[i];
        }
        avgTAT /= _N;
        avgWT /= _N;

        System.out.println("Average Turnaround Time: " + avgTAT);
        System.out.println("Average Waiting Time: " + avgWT);

        scanner.close();
    }
}
