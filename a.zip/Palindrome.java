import java.util.*;

public class Palindrome {
	public static void main(String args[]) {
		System.out.print("Enter the string to check : ");
		
		Scanner sc=new Scanner(System.in);
		String word =sc.nextLine();

		String reverseWord = "";
		for (int i=word.length()-1; i>=0; i--) {
			reverseWord += String.valueOf(word.charAt(i));
		}
		
		boolean matching = true;
		for (int i=0; i<word.length()-1; i++) {
			if (word.charAt(i) != reverseWord.charAt(i)) {
				matching = false;
				break;
			}
		}
		
		if (matching) System.out.println(word + " is a palindrome.");
		else System.out.println(word + " is not a palindrome.");
	}
}