import java.util.Scanner;

public class RR {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character after reading the integer input

        String PID[] = new String[n];
        int BT[] = new int[n];
        int CT[] = new int[n];
        int TAT[] = new int[n];
        int WT[] = new int[n];
        int timeQuantum;

        System.out.print("Enter PIDs: ");
        for (int i = 0; i < n; i++) {
            PID[i] = scanner.nextLine();
        }

        for (int i = 0; i < n; i++) {
            System.out.print("Enter BT for " + PID[i] + ": ");
            BT[i] = scanner.nextInt();
        }

        System.out.print("Enter the time quantum: ");
        timeQuantum = scanner.nextInt();

        scanner.close();

        int remainingTime[] = new int[n];
        for (int i = 0; i < n; i++) {
            remainingTime[i] = BT[i];
        }

        int currentTime = 0;
        int completedProcesses = 0;
        while (completedProcesses < n) {
            for (int i = 0; i < n; i++) {
                if (remainingTime[i] > 0) {
                    if (remainingTime[i] > timeQuantum) {
                        currentTime += timeQuantum;
                        remainingTime[i] -= timeQuantum;
                    } else {
                        currentTime += remainingTime[i];
                        CT[i] = currentTime;
                        TAT[i] = CT[i];
                        WT[i] = TAT[i] - BT[i];
                        remainingTime[i] = 0;
                        completedProcesses++;
                    }
                }
            }
        }

        // Print the results
        System.out.println("PID\tBT\tCT\tTAT\tWT");
        for (int i = 0; i < n; i++) {
            System.out.println(PID[i] + "\t" + BT[i] + "\t" + CT[i] + "\t" + TAT[i] + "\t" + WT[i]);
        }
    }
}
