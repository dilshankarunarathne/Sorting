import java.util.Scanner;

public class Priority {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character after reading the integer input

        String PID[] = new String[n];
        int BT[] = new int[n];
        int CT[] = new int[n];
        int priority_arr[] = new int[n];
        int TAT[] = new int[n];
        int WT[] = new int[n];

        System.out.print("Enter PIDs: ");
        for (int i = 0; i < n; i++) {
            PID[i] = scanner.nextLine();
        }

        for (int i = 0; i < n; i++) {
            System.out.print("Enter BT for " + PID[i] + ": ");
            BT[i] = scanner.nextInt();
        }

        for (int i = 0; i < n; i++) {
            System.out.print("Enter Priority for " + PID[i] + ": ");
            priority_arr[i] = scanner.nextInt();
        }

        scanner.close();

        // Perform priority scheduling
        int current_process = 1;
        int current_WT = 0;
        while (current_process <= 5) {
            for (int i = 0; i < n; i++) {
                if (current_process == priority_arr[i]) {
                    WT[i] = current_WT;
                    current_WT += BT[i];
                    TAT[i] = BT[i] + WT[i];
                    CT[i] = BT[i] + WT[i];
                }
            }
            current_process = current_process + 1;
        }

        // Print the results
        System.out.println("PID\tBT\tPri\tCT\tTAT\tWT");
        for (int i = 0; i < n; i++) {
            System.out.println(PID[i] + "\t" + BT[i] + "\t" + priority_arr[i] + "\t" + CT[i] + "\t" + TAT[i] + "\t" + WT[i]);
        }
    }
}
