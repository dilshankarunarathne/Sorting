public class TestSavingsAccount {
    public static void main(String[] args) {
        SavingsAccount saver1=new SavingsAccount();
        SavingsAccount saver2=new SavingsAccount();

        saver1.setSavingsBalance(2000.00);
        saver2.setSavingsBalance(3000.0);

        saver1.modifyInterestRate(0.04);
        saver2.modifyInterestRate(0.04);

        saver1.modifyInterestRate(0.05);
        saver2.modifyInterestRate(0.05);

        double saver1Interest=saver1.calculateMonthlyInterest();
        double saver2Interest=saver2.calculateMonthlyInterest();
        
        System.out.println("Sav balance for saver 1 = "+saver1.getSavingsBalance());
        System.out.println("Sav balance for saver 2 = "+saver2.getSavingsBalance());

    }
}
