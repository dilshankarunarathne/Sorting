import java.util.Scanner;
public class SavingsAccount {
    Scanner scanner=new Scanner(System.in);
    static double annualInterestRate;
    double savingsBalance;

    public SavingsAccount(){

    }

    public SavingsAccount(double annualInterestRate,double savingsBalance){
        this.annualInterestRate=annualInterestRate;
        this.savingsBalance=savingsBalance;
    }

    public double calculateMonthlyInterest(){
        double interest=savingsBalance*annualInterestRate/12;
        savingsBalance=savingsBalance+interest;
        return interest;
    }

    public void modifyInterestRate(double newInteresRate){
        annualInterestRate=newInteresRate;
    }

    public void setSavingsBalance(double newBal){
        savingsBalance=newBal;
    }

    public double getSavingsBalance(){
        return savingsBalance;
    }

    public double getAnnualInteresRate(){
        return annualInterestRate;
    }
}
