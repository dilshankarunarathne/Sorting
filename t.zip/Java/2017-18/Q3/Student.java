public class Student {
    String regNo;
    String status;
    float gpa;

    public String getRegNo(){
        return regNo;
    }

    public void setRegNo(String regNo){
        this.regNo=regNo;
    }

    public String getStatus(){
        return status;
    }

    public void setStatus(String statud){
        this.status=status;
    }

    public float getGpa(){
        return gpa;
    }

    public void setGpa(float gpa){
        this.gpa=gpa;
    }

    public String toString(){
        return "regNo : "+regNo+", status: "+status+" gpa: "+String.valueOf(gpa);
    }
}
