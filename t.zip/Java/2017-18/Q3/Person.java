public abstract class Person {
    String name;
    String NICNum;

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name=name;
    }
    public String getNICNum(){
        return NICNum;
    }
    public String toString(){
        return "{ Name : "+ name + ", NICNum: "+ NICNum +" }";
    }
}
