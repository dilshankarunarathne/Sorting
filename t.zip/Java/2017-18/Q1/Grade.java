/**
 * Grade
 */

import java.util.Scanner;

public class Grade {

    static Scanner scanner =new Scanner(System.in);

    public static void main(String[] args) {
        

        String regNo;
        int quizMarks=0,assMarks=0,midScore=0,finalMarks=0;

        regNo=getRegNo();

        boolean quizFlag=true;
        while(quizFlag){
            quizMarks=getQuizMarks();
            if(quizMarks<=10){
                quizFlag=false;
            }
            else{
                System.out.println("Invalid input!");
                quizFlag=true;
            }
        }


        boolean assFlag=true;
        while(assFlag){
            assMarks=getAssignmentMarks();
            if(assMarks<=10){
                assFlag=false;
            }
            else{
                System.out.println("Invalid input!");
                assFlag=true;
            }
        }


        boolean midFlag=true;
        while(midFlag){
            midScore=getMidScore();
            if(midScore<=20){
                midFlag=false;
            }
            else{
                System.out.println("Invalid input!");
                midFlag=true;
            }
        }


        boolean finalFlag=true;
        while(finalFlag){
            finalMarks=getFinalMark();
            if(finalMarks<=60){
                finalFlag=false;
            }
            else{
                System.out.println("Invalid input!");
                finalFlag=true;
            }
        }

        int totalScore=(quizMarks+assMarks+midScore+finalMarks);

        if(totalScore>55){
            System.out.println("Pass");
        }
        else{
            System.out.println("Fail");
        }

        
        System.out.print("Do you want to run again ? Y/N :");
        char again=scanner.next().charAt(0);
        if(again=='Y'){
            main(args);
        }
        else{
            System.out.println("Program ended!");
        }
        
        scanner.close();
    }

    private static String getRegNo(){
        System.out.println("Enter the registration number : ");
        String regNo=scanner.nextLine();
        return regNo;
    }

    private static int getQuizMarks(){
        System.out.println("Enter the quiz marks : ");
        int quiz=scanner.nextInt();
        return quiz;
    }

    private static int getAssignmentMarks(){
        System.out.println("Enter the assignment marks : ");
        int assMarks=scanner.nextInt();
        return assMarks;
    }

    private static int getMidScore(){
        System.out.println("Enter the mid exam marks : ");
        int midMark=scanner.nextInt();
        return midMark;
    }

    private static int getFinalMark(){
        System.out.println("Enter the final marks : ");
        int finalMark=scanner.nextInt();
        return finalMark;
    }
}