import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class TwoSumIndices {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();
        int[] nums = new int[size];

        // Prompt the user to input the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            System.out.print("Element " + (i + 1) + ": ");
            nums[i] = scanner.nextInt();
        }

        // Prompt the user to input the target value
        System.out.print("Enter the target value: ");
        int target = scanner.nextInt();

        // Find the indices of two numbers whose sum equals the target value
        int[] indices = findTwoSumIndices(nums, target);

        if (indices[0] != -1) {
            System.out.println("Indices of the two numbers whose sum equals the target value:");
            System.out.println(indices[0] + ", " + indices[1]);
        } else {
            System.out.println("No two numbers found with the given sum.");
        }

        scanner.close();
    }

    public static int[] findTwoSumIndices(int[] nums, int target) {
        Map<Integer, Integer> map = new HashMap<>();

        // Iterate through the array and find the complement of each number
        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];

            // Check if the complement exists in the map
            if (map.containsKey(complement)) {
                // If found, return the indices of the current element and its complement
                return new int[]{map.get(complement), i};
            }

            // Add the current element to the map with its index
            map.put(nums[i], i);
        }

        return new int[]{-1, -1}; // Return {-1, -1} if no solution is found
    }
}
