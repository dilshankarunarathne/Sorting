public class TestShapes {
    public static void main(String[] args) {
        // create objects for TwoDimensional child classes
        Triangle t = new Triangle(5.0, 7.0, 8.0);
        Rectangle r = new Rectangle(10.0, 5.0);
        Circle c = new Circle(3.0);
        
        // print the type of shape and its relevant data
        System.out.println(t.toString());
        System.out.println(r.toString());
        System.out.println(c.toString());
        
        // print the area and circumference of each shape
        System.out.println("Triangle area: " + t.getArea());
        System.out.println("Triangle circumference: " + t.getCircumference());
        System.out.println("Rectangle area: " + r.getArea());
        System.out.println("Rectangle circumference: " + r.getCircumference());
        System.out.println("Circle area: " + c.getArea());
        System.out.println("Circle circumference: " + c.getCircumference());
        
        // create objects for ThreeDimensional child classes
        Box b = new Box(3.0, 4.0, 5.0);
        Cone cn = new Cone(2.0, 4.0);
        Cylinder cy = new Cylinder(3.0, 6.0);
        Sphere s = new Sphere(4.0);
        
        // print the type of shape and its relevant data
        System.out.println(b.toString());
        System.out.println(cn.toString());
        System.out.println(cy.toString());
        System.out.println(s.toString());
        
        // print the surface area and volume of each shape
        System.out.println("Box surface area: " + b.getSurface());
        System.out.println("Box volume: " + b.getVolume());
        System.out.println("Cone surface area: " + cn.getSurface());
        System.out.println("Cone volume: " + cn.getVolume());
        System.out.println("Cylinder surface area: " + cy.getSurface());
        System.out.println("Cylinder volume: " + cy.getVolume());
        System.out.println("Sphere surface area: " + s.getSurface());
        System.out.println("Sphere volume: " + s.getVolume());
    }
}
