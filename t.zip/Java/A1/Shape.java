// Shape class is the super class
abstract class Shape {
    // abstract methods for calculating area, circumference, surface area and volume
    public abstract double getArea();
    public abstract double getCircumference();
    public abstract double getSurface();
    public abstract double getVolume();
    
    // toString method to print the type of shape and its relevant data
    public abstract String toString();
}

// Two Dimensional class is an abstract class that extends Shape class
abstract class TwoDimensional extends Shape {
    // abstract methods for calculating area and circumference
    public abstract double getArea();
    public abstract double getCircumference();
}

// Triangle class is a subclass of TwoDimensional class
class Triangle extends TwoDimensional {
    // instance variables
    private double base;
    private double height;
    private double side1;
    private double side2;
    private double side3;
    
    // constructor
    public Triangle(double base, double height, double side1, double side2, double side3) {
        this.base = base;
        this.height = height;
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }
    
    // methods for calculating area and circumference
    public double getArea() {
        return 0.5 * base * height;
    }
    
    public double getCircumference() {
        return side1 + side2 + side3;
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Triangle [Base=" + base + ", Height=" + height + ", Side1=" + side1 + ", Side2=" + side2 + ", Side3=" + side3 + "]";
    }
}

// Rectangle class is a subclass of TwoDimensional class
class Rectangle extends TwoDimensional {
    // instance variables
    private double height;
    private double width;
    
    // constructor
    public Rectangle(double height, double width) {
        this.height = height;
        this.width = width;
    }
    
    // methods for calculating area and circumference
    public double getArea() {
        return height * width;
    }
    
    public double getCircumference() {
        return 2 * (height + width);
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Rectangle [Height=" + height + ", Width=" + width + "]";
    }
}

// Circle class is a subclass of TwoDimensional class
class Circle extends TwoDimensional {
    // instance variable
    private double radius;
    
    // constructor
    public Circle(double radius) {
        this.radius = radius;
    }
    
    // methods for calculating area and circumference
    public double getArea() {
        return Math.PI * radius * radius;
    }
    
    public double getCircumference() {
        return 2 * Math.PI * radius;
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Circle [Radius=" + radius + "]";
    }
}

// Three Dimensional class is an abstract class that extends Shape class
abstract class ThreeDimensional extends Shape {
    // abstract methods for calculating surface area and volume
    public abstract double getSurface();
    public abstract double getVolume();
}

// Box class is a subclass of ThreeDimensional class
class Box extends ThreeDimensional {
    // instance variables
    private double height;
    private double width;
    private double length;
    
    // constructor
    public Box(double height, double width, double length) {
        this.height = height;
        this.width = width;
        this.length = length;
    }
    
    // methods for calculating surface area and volume
    public double getSurface() {
        return 2 * (height * width + width * length + length * height);
    }
    
    public double getVolume() {
        return height * width * length;
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Box [Height=" + height + ", Width=" + width + ", Length=" + length + "]";
    }
}

// Cone class is a subclass of ThreeDimensional class
class Cone extends ThreeDimensional {
    // instance variables
    private double radius;
    private double height;
    
    // constructor
    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }
    
    // methods for calculating surface area and volume
    public double getSurface() {
        return Math.PI * radius * (radius + Math.sqrt(height * height + radius * radius));
    }
    
    public double getVolume() {
        return (1.0 / 3.0) * Math.PI * radius * radius * height;
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Cone [Radius=" + radius + ", Height=" + height + "]";
    }
}

// Cylinder class is a subclass of ThreeDimensional class
class Cylinder extends ThreeDimensional {
    // instance variables
    private double radius;
    private double height;
    
    // constructor
    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }
    
    // methods for calculating surface area and volume
    public double getSurface() {
        return 2 * Math.PI * radius * (radius + height);
    }
    
    public double getVolume() {
        return Math.PI * radius * radius * height;
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Cylinder [Radius=" + radius + ", Height=" + height + "]";
    }
}

// Sphere class is a subclass of ThreeDimensional class
class Sphere extends ThreeDimensional {
    // instance variable
    private double radius;
    
    // constructor
    public Sphere(double radius) {
        this.radius = radius;
    }
    
    // methods for calculating surface area and volume
    public double getSurface() {
        return 4 * Math.PI * radius * radius;
    }
    
    public double getVolume() {
        return (4.0 / 3.0) * Math.PI * radius * radius * radius;
    }
    
    // methods for printing the type of shape and its relevant data
    public String toString() {
        return "Sphere [Radius=" + radius + "]";
    }
}

