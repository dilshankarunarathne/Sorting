public interface Book {
    static int accession_number=1;
    void getData();
    void print();
}
