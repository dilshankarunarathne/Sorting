import java.util.Scanner;

public class Roman {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the Roman number: ");
        String roman = scanner.nextLine();
        scanner.close();

        int decimal = 0;
        int previousValue = 0; // Track previous value for subtractive notation

        for (int i = 0; i < roman.length(); i++) {
            int currentValue = getValue(roman.charAt(i));

            if (currentValue > previousValue) {
                // Subtractive notation
                decimal += currentValue - (2 * previousValue); // Subtract previous value twice
            } else {
                decimal += currentValue;
            }

            previousValue = currentValue;
        }

        System.out.println("Decimal number of " + roman + " is " + decimal);
    }

    private static int getValue(char c) {
        switch (c) {
            case 'M':
                return 1000;
            case 'D':
                return 500;
            case 'C':
                return 100;
            case 'L':
                return 50;
            case 'X':
                return 10;
            case 'V':
                return 5;
            case 'I':
                return 1;
            default:
                return 0;
        }
    }
}
