import java.util.Scanner;

public class DecimalToRoman {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the decimal number: ");
        int decimal = scanner.nextInt();
        scanner.close();

        String roman = convertToRoman(decimal);
        System.out.println("Roman numeral of " + decimal + " is " + roman);
    }

    private static String convertToRoman(int decimal) {
        if (decimal <= 0 || decimal > 3999) {
            throw new IllegalArgumentException("Decimal number out of range");
        }

        StringBuilder roman = new StringBuilder();

        while (decimal >= 1000) {
            roman.append("M");
            decimal -= 1000;
        }
        while (decimal >= 900) {
            roman.append("CM");
            decimal -= 900;
        }
        while (decimal >= 500) {
            roman.append("D");
            decimal -= 500;
        }
        while (decimal >= 400) {
            roman.append("CD");
            decimal -= 400;
        }
        while (decimal >= 100) {
            roman.append("C");
            decimal -= 100;
        }
        while (decimal >= 90) {
            roman.append("XC");
            decimal -= 90;
        }
        while (decimal >= 50) {
            roman.append("L");
            decimal -= 50;
        }
        while (decimal >= 40) {
            roman.append("XL");
            decimal -= 40;
        }
        while (decimal >= 10) {
            roman.append("X");
            decimal -= 10;
        }
        while (decimal >= 9) {
            roman.append("IX");
            decimal -= 9;
        }
        while (decimal >= 5) {
            roman.append("V");
            decimal -= 5;
        }
        while (decimal >= 4) {
            roman.append("IV");
            decimal -= 4;
        }
        while (decimal >= 1) {
            roman.append("I");
            decimal -= 1;
        }

        return roman.toString();
    }
}
