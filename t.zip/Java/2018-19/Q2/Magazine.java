public interface Magazine {
    static int voulume_number=1;
    void getData();
    void print();
}
