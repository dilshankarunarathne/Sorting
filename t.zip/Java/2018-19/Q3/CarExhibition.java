public class CarExhibition {

    void addCar(double price,int year){}

    void addSportCar(double price,int year){}

    int getTotalPrice(){
        return 0;
    }
}

abstract class Car extends CarExhibition {

    double price;
    int year;

    public abstract String toString();
    abstract void calculatePrice();
    
    public Car(double price,int year){
        
    }

    public abstract double calcilateSalePrice();

    
}



abstract class SportCar extends Car {
    

    public double calcilateSalePrice(){
        if(year>2015){
            return price+price*0.75;
        }
        else if(year>2005){
            return price+price*0.5;
        }
        
    }


}



class ClassicCar extends Car {
    
    public ClassicCar(double price,int year){

    }

    public double calcilateSalePrice(){
        return 10;
    }
}

