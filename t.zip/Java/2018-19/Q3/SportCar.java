package Q3;

public class SportCar extends Car {
    
    public SportCar(double price, int year){
        this.year=year;
        this.price=price;
    }

    public double calcilateSalePrice(){
        if(year>2015){
            return price+price*0.75;
        }
        else if(year>2005){
            return price+price*0.5;
        }
        
    }


}
