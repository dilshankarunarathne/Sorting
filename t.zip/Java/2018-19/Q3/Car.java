

public abstract class Car extends CarExhibition {
    
    public Car(double price,int year){
        this.price=price;
        this.year=year;
    }

    abstract void calculatePrice();
}
