<?php
if (isset($_POST['find'])) {
    // Clear Existing Details
    $error = "";
    $gender = "";
    $year = "";
    $month = "";
    $day = "";

    $NICNo = $_POST['nic'];
    $dayText = 0;

    if (strlen($NICNo) != 10 && strlen($NICNo) != 12) {
        $error = "Invalid NIC NO";
    } elseif (strlen($NICNo) == 10 && !is_numeric(substr($NICNo, 0, 9))) {
        $error = "Invalid NIC NO";
    } else {
        // Year
        if (strlen($NICNo) == 10) {
            $year = "19" . substr($NICNo, 0, 2);
            $dayText = (int) substr($NICNo, 2, 3);
        } else {
            $year = substr($NICNo, 0, 4);
            $dayText = (int) substr($NICNo, 4, 3);
        }

        // Gender
        if ($dayText > 500) {
            $gender = "Female";
            $dayText = $dayText - 500;
        } else {
            $gender = "Male";
        }

        // Day Digit Validation
        if ($dayText < 1 || $dayText > 366) {
            $error = "Invalid NIC NO";
        } else {
            // Month
            if ($dayText > 335) {
                $day = $dayText - 335;
                $month = "December";
            } elseif ($dayText > 305) {
                $day = $dayText - 305;
                $month = "November";
            } elseif ($dayText > 274) {
                $day = $dayText - 274;
                $month = "October";
            } elseif ($dayText > 244) {
                $day = $dayText - 244;
                $month = "September";
            } elseif ($dayText > 213) {
                $day = $dayText - 213;
                $month = "August";
            } elseif ($dayText > 182) {
                $day = $dayText - 182;
                $month = "July";
            } elseif ($dayText > 152) {
                $day = $dayText - 152;
                $month = "June";
            } elseif ($dayText > 121) {
                $day = $dayText - 121;
                $month = "May";
            } elseif ($dayText > 91) {
                $day = $dayText - 91;
                $month = "April";
            } elseif ($dayText > 60) {
                $day = $dayText - 60;
                $month = "March";
            } elseif ($dayText < 32) {
                $month = "January";
                $day = $dayText;
            } elseif ($dayText > 31) {
                $day = $dayText - 31;
                $month = "February";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>NIC Number Details</title>
</head>

<body>
    <form method="POST">
        <input type="text" name="nic" placeholder="Enter NIC Number" required>
        <button type="submit" name="find">Find Details</button>
    </form>
    <?php if (isset($_POST['find'])): ?>
        <?php if (!empty($error)): ?>
            <p>
                <?php echo $error; ?>
            </p>
        <?php else: ?>
            <p>Gender:
                <?php echo $gender; ?>
            </p>
            <p>Year:
                <?php echo $year; ?>
            </p>
            <p>Month:
                <?php echo $month; ?>
            </p>
            <p>Day:
                <?php echo $day; ?>
            </p>
        <?php endif; ?>
    <?php endif; ?>
</body>

</html>