<?php 
    $string="Hello World";
    if(preg_match('/^[a-zA-Z\s]+$/' , $string)){
        echo "contain only letters and white spaces.";
    }
    else{
        echo "not contain";
    }
?>