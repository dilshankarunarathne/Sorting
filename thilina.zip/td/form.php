<html>

    <head>
        <title>Form</title>
    </head>

    <body>

    <p style='color:red;'>* required fields</p>

        <form action="form.php" method="POST">
            <label for="name">Name</label>
            <input type="text" name="name" id="name"><span style='color:red;'>*</span>
            <?php 
                if($_SERVER['REQUEST_METHOD']=="POST"){
                    $name=$_POST["name"];
                    if(empty($name)){
                        echo "<span style='color:red;'>Name required </span><br>";
                    }
                }
            ?>
            <br><br>

            <label for="email">Email</label>
            <input type="email" name="email" id="email"><span style='color:red;'>*</span>
            <?php
            if ($_SERVER['REQUEST_METHOD'] == "POST") {
                $email = $_POST["email"];
                if (empty($email)) {
                    echo "<span style='color:red;'>email required </span><br>";
                }
            }
            ?>
            <br><br>

            <label for="url">Website</label>
            <input type="url" name="url" id="url"><br><br>

            <label for="comment">Comment</label>
            <textarea name="comment" id="comment"></textarea><br><br>

            <label>Gender : </label>
            <input type="radio" name="gender" id="female" value="female">
            <label for="female">Female</label>
            <input type="radio" name="gender" id="male" value="male">
            <label for="male">Male</label>
            <input type="radio" name="gender" id="other" value="other">
            <label for="other">Other</label><br><br>

            <input type="submit">
        </form>

    </body>

</html>
