<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guestDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Inserting data into the table
$sql = "INSERT INTO guests (guestname, address, email, phone_no, room_type, arri_date, dept_date)
VALUES ('John Doe', '123 Main St', 'johndoe@gmail.com', '0771233456', 'Single room', '2023-05-10 10:00:00', '2023-05-12 12:00:00'),
        ('Jane Smith', '456 High St', 'janesmith@gmail.com', '0712348790', 'Double room', '2023-05-11 11:00:00', '2023-05-13 13:00:00'),
        ('Bob Johnson', '789 Elm St', 'bobjohnson@gmail.com', '0723455678', 'Triple room', '2023-05-12 12:00:00', '2023-05-14 14:00:00'),
        ('Alice Brown', '321 Oak St', 'alicebrown@gmail.com', '0757899234', 'Queen room', '2023-05-13 13:00:00', '2023-05-15 15:00:00'),
        ('Tom Wilson', '654 Pine St', 'tomwilson@gmail.com', '0788765432', 'King room', '2023-05-14 14:00:00', '2023-05-16 16:00:00')";

if ($conn->query($sql) === TRUE) {
    echo "Records inserted successfully";
} else {
    echo "Error inserting records: " . $conn->error;
}

// Close database connection
$conn->close();
?>