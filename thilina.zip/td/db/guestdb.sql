-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2023 at 09:38 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guestdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `guestname` varchar(40) DEFAULT NULL,
  `address` varchar(60) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone_no` varchar(20) DEFAULT NULL,
  `room_type` varchar(15) DEFAULT NULL,
  `arri_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dept_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`guestname`, `address`, `email`, `phone_no`, `room_type`, `arri_date`, `dept_date`) VALUES
('John Doe', '123 Main St', 'johndoe@gmail.com', '0771233456', 'Single room', '2023-05-10 04:30:00', '2023-05-12 06:30:00'),
('Jane Smith', '456 High St', 'janesmith@gmail.com', '0712348790', 'Double room', '2023-05-11 05:30:00', '2023-05-13 07:30:00'),
('Bob Johnson', '789 Elm St', 'bobjohnson@gmail.com', '0723455678', 'Triple room', '2023-05-12 06:30:00', '2023-05-14 08:30:00'),
('Alice Brown', '321 Oak St', 'alicebrown@gmail.com', '0757899234', 'Queen room', '2023-05-13 07:30:00', '2023-05-15 09:30:00'),
('Tom Wilson', '654 Pine St', 'tomwilson@gmail.com', '0788765432', 'King room', '2023-05-14 08:30:00', '2023-05-16 10:30:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
