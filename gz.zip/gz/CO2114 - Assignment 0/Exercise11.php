<?php
header('Location: https://www.w3resource.com/');
?>