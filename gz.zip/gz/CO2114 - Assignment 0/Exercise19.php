<?php
$d = 'A00';
  for ($n=0; $n<5; $n++)
{
echo ++$d ."\n";
}
?>