<?php
$x = '000547023.24';
$str1 = ltrim($x, '0');
echo $str1."\n";
?>
