<?php
echo 'Current script owner: ' . get_current_user()."\n";
?>