<?php
$path = 'www.example.com/public_html/index.php';
$file = basename($path, ".php"); 
echo $file."\n";
?>
