<?php
function test($s1)
{ 
   return substr(substr($s1, 1, strlen($s1) - 1), 0, strlen($s1) - 2);
}

echo test("Hello")."\n";
echo test("Hi")."\n";
echo test("Python")."\n";
