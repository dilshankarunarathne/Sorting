<?php
$timestamp = strtotime('12-05-2014');
echo $timestamp."\n";
?>
