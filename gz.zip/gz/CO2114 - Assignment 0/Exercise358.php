<?php
echo date("Y/m/d") . "\n";
echo date("y.m.d") . "\n";
echo date("d-m-y")."\n";
?>
