<?php
//all uppercase letters
print(strtoupper("the quick brown fox jumps over the lazy dog."))."\n";
//all lowercase letters
print(strtolower("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"))."\n";
// make a string's first character uppercase
print(ucfirst("the quick brown fox jumps over the lazy dog."))."\n";
// make a string's first character of all the words uppercase
print(ucwords("the quick brown fox jumps over the lazy dog."))."\n";
?>
