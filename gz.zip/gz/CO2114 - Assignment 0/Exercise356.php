<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Copyright Information</title>
</head>
<body>
<p>© <?php echo date('Y'); ?> PHP Exercises - w3resource</p>
</body>
</html>
