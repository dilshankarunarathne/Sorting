<?php
echo date("M - Y")."\n";
echo date("M - Y",strtotime("-1 Months"))."\n";
echo date("M - Y",strtotime("-2 Months"))."\n";
echo date("M - Y",strtotime("-3 Months"))."\n";
?>
