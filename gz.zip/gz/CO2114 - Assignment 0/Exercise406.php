<?php
$val = '4.5e3';
$ival = (int) $val;
$fval = (float) $val;
echo $ival."\n";
echo $fval."\n";
?>
