<?php
//Licence: https://bit.ly/2CFA5XY

function variadicFunction($operands)
{
    $sum = 0;
    foreach($operands as $singleOperand) {
        $sum += $singleOperand;
    }
    return $sum;
}

var_dump(variadicFunction([1, 2]));
var_dump(variadicFunction([1, 2, 3, 4]));
  
?>
