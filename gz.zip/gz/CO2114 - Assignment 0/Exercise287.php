<?php
    function array_filter_by_value($my_array, $index, $value)
    { 
        if(is_array($my_array) && count($my_array)>0)  
        { 
            foreach(array_keys($my_array) as $key){ 
                $temp[$key] = $my_array[$key][$index]; 
                 
                if ($temp[$key] == $value){ 
                    $new_array[$key] = $my_array[$key]; 
                } 
            } 
          } 
      return $new_array; 
    } 
$colors = array( 
   0 => array('key1' => 'Red', 'key2' => 'Green', 'key3' => 'Black'), 
   1 => array('key1' => 'Yellow', 'key2' => 'White', 'key3' => 'Pink') 
); 
$results = array_filter_by_value($colors, 'key2', 'White');     
print_r($results);      
?>