<?php
print_r(array_combine(range(20, 25),range(2,7)));
?>
