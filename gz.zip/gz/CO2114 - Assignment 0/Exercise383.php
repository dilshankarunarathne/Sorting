<?php
$str1 = 'rayy@example.com';
echo substr($str1, -3)."\n";
?>
