<?php
echo "Last modified: " . date ("F d Y H:i:s.", getlastmod())."\n";
?>