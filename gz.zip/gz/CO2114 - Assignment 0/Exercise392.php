<?php
$str = 'rayy@example.com';
echo bin2hex($str)."\n";
?>
