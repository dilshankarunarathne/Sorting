<?php
print_r(get_extension_funcs("JSON"));
echo "\n";
print_r(get_extension_funcs("XML"))."\n";
?>