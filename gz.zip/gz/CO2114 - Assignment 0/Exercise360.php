<?php
$odate = "2012-09-12";
$newDate = date("d-m-Y", strtotime($odate));
echo $newDate."\n";
?>
