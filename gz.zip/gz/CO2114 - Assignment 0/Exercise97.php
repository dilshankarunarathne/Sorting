<?php
//Licence: https://bit.ly/2CFA5XY

function decapitalize($string, $upperRest = false)
{
    return lcfirst($upperRest ? strtoupper($string) : $string);
}
print_r(decapitalize('Python'));

?>
