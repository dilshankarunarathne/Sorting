<?php
$dates = array('2015-02-01', '2015-02-02', '2015-02-03');
echo "Latest Date: ". max($dates)."\n";
echo "Earliest Date: ". min($dates)."\n";
?>
