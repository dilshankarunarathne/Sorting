<?php
echo date('m', strtotime('-1 month'))."\n";
?>
