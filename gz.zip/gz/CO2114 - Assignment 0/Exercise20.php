<?php
echo $x;
  print_r(error_get_last());
?>
