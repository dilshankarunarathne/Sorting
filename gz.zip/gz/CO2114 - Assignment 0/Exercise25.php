<?php
// getenv() gets the value of an environment variable
$rd = getenv('DOCUMENT_ROOT');
echo $rd."\n";
?>