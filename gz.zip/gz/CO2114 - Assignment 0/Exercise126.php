<?php
function test($s) 
{
   return strlen($s) < 3 ? strtoupper($s) : substr($s, 0, strlen($s) - 3).strtoupper(substr($s, strlen($s) - 3));
 }


echo test("Python")."\n";
echo test("Javascript")."\n";
echo test("js")."\n";
echo test("PHP")."\n";
?>