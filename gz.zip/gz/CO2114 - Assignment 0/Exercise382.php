<?php
$mailid  = 'rayy@example.com';
$user = strstr($mailid, '@', true);
echo $user."\n";
?>
