<?php
echo "Tomorrow I \'ll learn PHP global variables."."\n"; 
echo "This is a bad command : del c:\\*.*"."\n"; 
?>