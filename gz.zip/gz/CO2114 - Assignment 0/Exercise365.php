<?php
var_dump(checkdate(2, 30, 2008));
var_dump(checkdate(2, 29, 2008));
?>
