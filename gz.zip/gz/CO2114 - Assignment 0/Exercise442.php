<?php
echo 'Number of days for the month of '.date('M'). ' is :' .date('t')."\n";
?>
