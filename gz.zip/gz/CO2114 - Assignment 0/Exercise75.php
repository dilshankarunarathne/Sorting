<?php
class Node {
    public $left_part;
    public $right_part;
    public $value;
    public $largest;
 
    public function __construct($value) {
        $this->value = $value;
    }
 
    public function max_value() {
        if ($this->largest !== null) {
            return $this->largest;
        }
        if (is_null($this->left_part) && is_null($this->right_part)) {
            return $this->value;
        }
        $left_part  = is_null($this->left_part)  ? -1 : $this->left_part->max_value();
        $right_part = is_null($this->right_part) ? -1 : $this->right_part->max_value();
 
        return $this->largest = $this->value + max($left_part, $right_part);
    }
}
 
$diamond = array();
 
while ($line = trim(fgets(STDIN))) {
    $diamond[] = explode(',', $line);
}
 
$nodes = array();
for ($i = 0; $i < count($diamond); $i++) {
    for ($j = 0; $j < count($diamond[$i]); $j++) {
        $nodes[$i][$j] = new Node($diamond[$i][$j]);
    }
}
 
for ($i = 0; $i < count($nodes); $i++) {
    for ($j = 0; $j < count($nodes[$i]); $j++) {
        $n = $nodes[$i][$j];
        if ($i < count($diamond)/2 - 1) {
            $n->left_part  = isset($nodes[$i + 1][$j])     ? $nodes[$i + 1][$j]     : null;
            $n->right_part = isset($nodes[$i + 1][$j + 1]) ? $nodes[$i + 1][$j + 1] : null;
        } else {
            $n->left_part  = isset($nodes[$i + 1][$j - 1]) ? $nodes[$i + 1][$j - 1] : null;
            $n->right_part = isset($nodes[$i + 1][$j])     ? $nodes[$i + 1][$j]     : null;
        }
    }
}
 
$top = $nodes[0][0];
 
echo $top->max_value() . "\n";

?>
