<?php
for($a=0; $a< 10; $a++)
 { 
   for($b=0; $b< 10; $b++)
      {
	     echo $a.$b.", "; 
      }
 }
 printf("\n"); 
?>