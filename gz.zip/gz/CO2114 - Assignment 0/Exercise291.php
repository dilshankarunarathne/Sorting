<?php
$a = array_fill(0, 4, array_fill(0, 4, 10));
  print_r($a);
?>