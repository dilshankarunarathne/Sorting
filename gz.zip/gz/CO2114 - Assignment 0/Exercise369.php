<?php
date_default_timezone_set('America/Los_Angeles');
$date = date('m/d/Y h:i:s a', time());
echo $date;
?>
