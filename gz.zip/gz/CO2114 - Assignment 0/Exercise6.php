<?php
echo "Your User Agent is :" . $_SERVER ['HTTP_USER_AGENT'];
?>