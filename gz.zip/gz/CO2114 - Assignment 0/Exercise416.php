<?php
$json = '{"number": 123456789012345678901234567890}';
var_dump(json_decode($json));
?>
