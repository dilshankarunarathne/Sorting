<?php
ini_set('date.timezone','America/New_York'); 
echo '<p>'.date("g:i A").'</p>'."\n";
?>
