<?php
$x =  20;            // $x is an integer
$str1 = (string)$x; // $str1 is a string now
// Check whether $x and $str1 are equal or not
if ($x === $str1) 
{
  echo "They are the same"."\n";
}
else
{
echo "They are not same"."\n";
}
?>
