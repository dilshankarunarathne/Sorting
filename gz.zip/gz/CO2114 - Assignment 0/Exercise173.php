<?php
function test($s1)
{ 
 
   return substr($s1, strlen($s1)-2, 2);

}

var_dump(test("Hello"));
var_dump(test("Python"));
var_dump(test("on"));
var_dump(test("o"));
