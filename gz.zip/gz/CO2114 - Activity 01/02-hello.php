<?php
	// Some code to be executed
	echo "Hello, world!";
?>
