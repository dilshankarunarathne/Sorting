<?php
	$txt1 = "Hello";
	$txt2 = " world!";
	$txt1 .= $txt2;
	
	echo $txt1;
?>
