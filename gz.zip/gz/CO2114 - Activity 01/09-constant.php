<?php
	// Defining constant
	define("SITE_URL", "https://www.tc.esn.ac.lk");
	
	// Using constant
	echo 'Thank you for visiting - ' . SITE_URL;
?>