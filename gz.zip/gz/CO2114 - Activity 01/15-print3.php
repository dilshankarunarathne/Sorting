<?php
	// Defining variables
	$txt = "Hello World!";
	$num = 123456789;
	$colors = array("Red", "Green", "Blue");
	
	// Displaying variables
	print $txt;
	print "<br>";
	print $num;
	print "<br>";
	print $colors[0];
?>
