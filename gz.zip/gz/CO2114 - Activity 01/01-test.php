<html>
	<head>
		<title>PHP-Test</title>
	</head>
	
	<body>
		<?php 
			echo '<p>Welcome to Trincomalee Campus</p>';
		?>
	</body>
</html>