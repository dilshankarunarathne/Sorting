<?php
	// Defining variables
	$txt = "Hello World!";
	$num = 123456789;
	$colors = array("Red", "Green", "Blue");
	
	// Displaying variables
	echo $txt;
	echo "<br>";
	echo $num;
	echo "<br>";
	echo $colors[0];
?> 