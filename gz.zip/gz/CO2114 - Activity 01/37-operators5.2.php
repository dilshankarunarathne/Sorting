<?php
	$x = 100;
	$y = 50;
	
	if ($x == 100 or $y == 80) 
	{
		echo "Hello world!";
	}
?>