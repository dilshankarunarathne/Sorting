<?php
	$x = 10;
	echo $x++;
?>