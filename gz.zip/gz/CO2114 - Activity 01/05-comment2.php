<?php
	/*
	This is a multiple line comment block
	that spans across more than
	one line
	*/
	echo "Hello, world!";
?>