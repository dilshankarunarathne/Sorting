<?php
	$x = 100;
	if ($x !== 90) 
	{
		echo "Hello world!";
	}
?>
