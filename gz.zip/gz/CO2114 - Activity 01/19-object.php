<?php
	class Car 
	{
		//Properties
		public $name;
		public $color;
		
		//Methods
		function set_name($name)
		{
			$this->name=$name;
		}
		
		//Methods
		function get_name()
		{
			return $this->name;
		}
	}//End of class
?> 