<?php
	echo str_replace("world", "Globe", "Hello world!");
	//outputs Hello Globe!
?>