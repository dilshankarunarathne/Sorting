<html>
	<html lang="en">
	
	<head>
		<meta charset="UTF-8">
		<title>A Simple PHP File</title>
	</head>
	
	<body>
		<h1>
			<?php 
				echo "Hello, world!"; 
			?>
		</h1>
	</body>
</html>