<?php
	//Declaring variables
	$txt="HelloWorld!";
	$number=10;
	
	//Displaying variables value
	echo $txt; //Output: HelloWorld!
	echo $number; //Output:10
?> 