<?php
	// Displaying string of text
	print "Hello World!";
?>
