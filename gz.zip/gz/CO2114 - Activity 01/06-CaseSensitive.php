<?php
	// Assign value to variable
	$color = "blue";
	// Try to print variable value
	echo "The color of the sky is " . $color . "<br>";
	echo "The color of the sky is " . $Color . "<br>";
	echo "The color of the sky is " . $COLOR . "<br>";
?> 