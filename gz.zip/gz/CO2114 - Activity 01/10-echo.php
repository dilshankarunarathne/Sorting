<?php
	// Displaying string of text
	echo "Hello World!";
?>
