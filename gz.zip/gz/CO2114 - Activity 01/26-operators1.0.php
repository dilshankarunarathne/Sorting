<?php
	$x = 100;
	$y = 6;
	
	echo $x;
	$x += 10;
	
	echo $x;
	
	$x -= 30;
	
	echo $x;
	echo $x * $y;
	
	$x = 10;
	$x /= 5;
	
	echo $x;
	
	$x = 15;
	$x %= 4;
	
	echo $x;
?>