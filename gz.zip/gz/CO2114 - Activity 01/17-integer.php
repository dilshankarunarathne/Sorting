<?php
	$x = 4521;
	var_dump($x);
?>
