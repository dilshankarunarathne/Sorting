<?php
	// Assign value to variable
	$color = "blue";
	
	// Get the type of a variable
	echo gettype($color) . "<br>";
	echo GETTYPE($color) . "<br>";
?>
