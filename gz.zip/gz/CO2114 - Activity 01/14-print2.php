<?php
	// Displaying HTML code
	print "<h4>This is a simple heading.</h4>";
	print "<h4 style='color: red;'>This is heading with style.</h4>";
?>
