<?php
	$x = 100;
	$y = 6;
	
	echo $x;
	echo "<br>";
	$x += 10;
	
	echo $x;
	echo "<br>";
	
	$x -= 30;
	
	echo $x;
	echo "<br>";
	echo $x * $y;
	echo "<br>";
	
	$x = 10;
	$x /= 5;
	
	echo $x;
	echo "<br>";
	
	$x = 15;
	$x %= 4;
	
	echo $x;
?>